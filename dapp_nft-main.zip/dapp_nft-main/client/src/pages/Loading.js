function Loading() {
    return (
      <>
        <section className="loading__page1 loading__page2">
        </section>
      </>
    );
  }
  
  export default Loading;
  