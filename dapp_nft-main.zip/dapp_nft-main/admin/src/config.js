
/* eslint-disable max-len */
export const host = process.env.WEBSITE_HOSTNAME || `http://146.190.70.132:5000`;

